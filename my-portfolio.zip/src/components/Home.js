import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <section className="home section" id="home">
      <div className="home_container container grid">
        <div className="home_data">
          <span className="home_greeting">Hello, I'm</span>
          <h1 className="home_name">Wissam Ouklah</h1>
          <h3 className="home_education">Junior Front-End Developer</h3>
          <div className="home_buttons">
            <a download="" href="pdf/" className="button button--ghost">
              Download CV
            </a>
            <a href="#about" className="button">About me</a>
          </div>
        </div>
        <div className="home_handle">
          <img src="Picsart_22-12-20_12-01-10-239.jpg" alt="" className="home_img" />
        </div>
        <div className="home_social">
          <a href="https://github.com/Exodiaaa" className="home_social-link" target="_blank">
            <i className='bx bxl-github'></i>
          </a>
          <a href="https://www.linkedin.com/in/wessam-ouklah" className="home_social-link" target="_blank">
            <i className='bx bxl-linkedin-square'></i>
          </a>
        </div>
        <a href="#about" className="home_scroll">
          <i className='bx bx-mouse home_scroll-icon'></i>
          <span className="home_scroll-name">Scroll Down</span>
        </a>
      </div>
    </section>
  );
};

export default Home;