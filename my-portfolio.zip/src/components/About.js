import React from 'react';
import './About.css';

const About = () => {
  return (
    <section className="about section" id="about">
      <span className="section_subtitle">My Intro</span>
      <h2 className="section_title">About Me</h2>
      <div className="about_container container grid">
        <img src="20230325_182824.jpg" alt="" className="about_img" />
        <div className="c1">
          <div className="about_data">
            <p className="about_description">
              Junior Front-end developer with a passion for learning new technologies, Eager to develop skills in a fast-paced environment.
              Over two years of experience in web development, including front-end technologies.
              More than two years of experience working with official government agencies and private companies.
              I also have a passion for design and knowledge of UI design, in addition to my obsession with photography, what a strange combination 😃.
            </p>
            <a href="#contact" className="button">Contact Me</a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;