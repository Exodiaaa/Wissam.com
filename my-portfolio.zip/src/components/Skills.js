import React from 'react';
import './Skills.css';

const Skills = () => {
  return (
    <section className="skills section" id="skills">
      <span className="section_subtitle">My abilities</span>
      <h2 className="section_title">My Experience</h2>
      <div className="skills_container container grid">
        <div className="skills_content">
          <h3 className="skills_title">Frontend Developer</h3>
          <div className="skills_box">
            <div className="skills_group">
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">HTML</h3>
                </div>
              </div>
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">CSS</h3>
                </div>
              </div>
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">JS</h3>
                </div>
              </div>
            </div>
            <div className="skills_group">
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">BootStrap</h3>
                </div>
              </div>
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">React.JS</h3>
                </div>
              </div>
              <div className="skills_data">
                <i className='bx bxs-checkbox-checked'></i>
                <div>
                  <h3 className="skills_name">GIT</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;