import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer_container container">
        <h1 className="footer_title">Wissam Ouklah</h1>
        <ul className="footer_list">
          <li>
            <a href="#about" className="footer_link">About</a>
          </li>
          <li>
            <a href="https://github.com/Exodiaaa" className="footer_link">Projects</a>
          </li>
        </ul>
        <ul className="footer_social">
          <a href="https://www.facebook.com/semo.wezo" target="_blank" className="footer_social-link">
            <i className='bx bxl-facebook'></i>
          </a>
          <a href="https://www.instagram.com/semoexodia/" target="_blank" className="footer_social-link">
            <i className='bx bxl-instagram'></i>
          </a>
        </ul>
        <span className="footer_copy">
          &#169; Wissam Ouklah. All rights reserved
        </span>
      </div>
    </footer>
  );
};

export default Footer;