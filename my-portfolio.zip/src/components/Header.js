import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <header className="header" id="header">
      <nav className="nav container">
        <a href="#" className="nav_logo">Wissam Ouklah</a>
        <div className="nav_menu">
          <ul className="nav_list">
            <li className="nav_item">
              <a href="#home" className="nav_link active-link">
                <i className='bx bx-home'></i>
              </a>
            </li>
            <li className="nav_item">
              <a href="#about" className="nav_link">
                <i className='bx bxs-user'></i>
              </a>
            </li>
            <li className="nav_item">
              <a href="#skills" className="nav_link">
                <i className='bx bxs-book'></i>
              </a>
            </li>
            <li className="nav_item">
              <a href="#contact" className="nav_link">
                <i className='bx bx-message-dots'></i>
              </a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  );
};

export default Header;