import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <section className="contact section" id="contact">
      <span className="section_subtitle">Get in touch</span>
      <h2 className="section_title">Contact Me</h2>
      <div className="contact_container container grid">
        <div className="contact_content">
          <h3 className="contact_title">Talk to me</h3>
          <div className="contact_info">
            <div className="contact_card">
              <i className='bx bx-mail-send contact_card-icon'></i>
              <h3 className="contact_card-title">Email</h3>
              <span className="contact_card-data">Wessam.ouklah@gmail.com</span>
              <a href="mailto:wessam.ouklah@gmail.com" target="_blank" className="contact_button">
                Write Me <i className='bx bx-right-arrow-alt contact_button-icon'></i>
              </a>
            </div>
          </div>
          <div className="contact_info">
            <div className="contact_card">
              <i className='bx bxl-whatsapp contact_card-icon'></i>
              <h3 className="contact_card-title">Whatsapp</h3>
              <span className="contact_card-data">+963930856714</span>
              <a href="https://api.whatsapp.com/send?phone=+963930856714&text=Hello, more information!" target="_blank" className="contact_button">
                Write Me <i className='bx bx-right-arrow-alt contact_button-icon'></i>
              </a>
            </div>
          </div>
        </div>
        <div className="contact_content">
          <h3 className="contact_title">Write me your project</h3>
          <form action="" className="contact_form">
            <div className="contact_form-div">
              <label htmlFor="" className="contact_form-tag">Name</label>
              <input type="text" className="contact_form-input" placeholder="Insert your name" />
            </div>
            <div className="contact_form-div">
              <label htmlFor="mail" className="contact_form-tag">Mail</label>
              <input type="text" className="contact_form-input" placeholder="Insert your email" />
            </div>
            <div className="contact_form-div contact_form-area">
              <label htmlFor="" className="contact_form-tag">Project</label>
              <textarea name="" id="" cols="30" rows="10" className="contact_form-input" placeholder="Write your project"></textarea>
            </div>
            <button className="button">Send Message</button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;